package com.example.nf_final_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ListActivity extends AppCompatActivity {

    ConstraintLayout Layout2;
    SharedPreferences sp;

    RadioGroup Fr;
    RadioButton Apple;
    RadioButton Banana;
    RadioButton Orange;
    RadioButton Pear;

    ImageView fruitImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_activity);

        Layout2 = findViewById(R.id.Layout2);
        int color = 0xFFA4D8D8;
        Layout2.setBackgroundColor(color);

        fruitImage = findViewById(R.id.imageView);
        initSettings();
        initFruits();
    }

    private void initFruits(){
        Fr = findViewById(R.id.Fruits);
        Apple = findViewById(R.id.Apple);
        Banana = findViewById(R.id.Banana);
        Orange = findViewById(R.id.Orange);
        Pear = findViewById(R.id.Pear);
        setFruitSelection(getFruitPreference());
        loadFruitImage();

        Fr.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                setFruitPreference();
                loadFruitImage();
            }
        });
    }

    private void loadFruitImage() {
        String fruitString = getFruitSelection();
        int imageId;

        switch (fruitString) {
            case "Apple":
                imageId = R.drawable.apple;
                break;
            case "Banana":
                imageId = R.drawable.banana;
                break;
            case "Orange":
                imageId = R.drawable.orange;
                break;
            case "Pear":
                imageId = R.drawable.pear;
                break;
            default:
                // Fallback to displaying something in the extremely
                // unlikely scenario no option is selected to prevent crashing
                imageId = R.drawable.ic_launcher_background;
        }
        fruitImage.setImageResource(imageId);
    }

    private void setFruitSelection(String fruit) {
        switch(fruit) {
            case "Apple":
                Fr.check(R.id.Apple);
                break;
            case "Banana":
                Fr.check(R.id.Banana);
                break;
            case "Orange":
                Fr.check(R.id.Orange);
                break;
            case "Pear":
                Fr.check(R.id.Pear);
                break;
        }
    }

    private String getFruitSelection() {
        int selectedId = Fr.getCheckedRadioButtonId();

        try {
            RadioButton selectedRB = findViewById(selectedId);
            return (String) selectedRB.getText();
        } catch (Exception e) {
            return "";
        }
    }

    private void setFruitPreference() {
        SharedPreferences.Editor spe = sp.edit();
        spe.putString("favoriteFruit", getFruitSelection());
        spe.apply();
    }

    private String getFruitPreference() {
        return sp.getString("favoriteFruit", "");
    }

    private void initSettings(){
        sp = getSharedPreferences("FruitsSharedPreferences", Context.MODE_PRIVATE);
    }

}