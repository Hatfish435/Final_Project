package com.example.nf_final_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ConstraintLayout Layout1;
    SharedPreferences sp;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
         sp = getSharedPreferences("FruitsSharedPreferences", Context.MODE_PRIVATE);
         tv = findViewById(R.id.fruitDeclaration);
         initListButton();

         Layout1 = findViewById(R.id.Layout1);
         int color = 0xFFC1E1C1;
         Layout1.setBackgroundColor(color);
    }

    private void initListButton(){
        Button ListButton = findViewById(R.id.ListButton);
        ListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    public void onResume(){
        super.onResume();
        String favoriteFruit = sp.getString("favoriteFruit", "");

        if (favoriteFruit == "") {
            tv.setText("I don't have a favorite fruit yet...");
        } else {
            tv.setText(String.format("My favorite fruit is '%s'", favoriteFruit));
        }
    }
}